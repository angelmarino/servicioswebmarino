<?php

// titulo ftp
$title = 'titulo de mi ftp';

// tamaño max fichero permitido 3 MB
$file_size = 1048576 * 10;

// fichero permitido
$file_type = array( 'png' );

// proteger con pass usuario normal
$pass = false;

// proteger con pass admin
$super_pass = false;

// los usuarios pueden borrar ficheros?
$can_delete = true;

?>